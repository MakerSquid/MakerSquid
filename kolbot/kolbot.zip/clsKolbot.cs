using System;

namespace kolbot
{
	/// <summary>
	/// Summary description for clsKolbot.
	/// </summary>
	public class clsKolbot
	{
		public clsKolbot()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
